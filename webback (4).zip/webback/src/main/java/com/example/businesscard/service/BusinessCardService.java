package com.example.businesscard.service;

import com.example.businesscard.entity.BusinessCard;
import com.example.businesscard.repository.BusinessCardRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BusinessCardService {

    @Autowired
    private BusinessCardRepository businessCardRepository;

    // 특정 ID의 명함 반환
    public Optional<BusinessCard> getBusinessCardById(Long id) {
        return businessCardRepository.findById(id);
    }

    // 명함 삭제
    @Transactional
    public void deleteBusinessCard(Long id) {
        businessCardRepository.deleteById(id);
    }

    // 명함 저장
    @Transactional
    public void saveBusinessCard(BusinessCard card) {
        businessCardRepository.save(card);
    }

    // 모든 명함 가져오기
    public List<BusinessCard> getAllBusinessCards() {
        return businessCardRepository.findAll();
    }

    // 명함 업데이트
    @Transactional
    public void updateBusinessCard(BusinessCard updatedCard) {
        Optional<BusinessCard> existingCardOpt = businessCardRepository.findById(updatedCard.getId());
        if (existingCardOpt.isPresent()) {
            BusinessCard existingCard = existingCardOpt.get();
            existingCard.setName(updatedCard.getName());
            existingCard.setPosition(updatedCard.getPosition());
            existingCard.setPhoneNumber(updatedCard.getPhoneNumber());
            existingCard.setOfficePhone(updatedCard.getOfficePhone());
            existingCard.setEmail(updatedCard.getEmail());
            existingCard.setAddress(updatedCard.getAddress());
            existingCard.setImage(updatedCard.getImage());

            businessCardRepository.save(existingCard);  // 수정된 명함 정보 저장
        }
    }
}
