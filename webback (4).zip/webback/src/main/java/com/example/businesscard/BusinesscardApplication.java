package com.example.businesscard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinesscardApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinesscardApplication.class, args);
	}

}
