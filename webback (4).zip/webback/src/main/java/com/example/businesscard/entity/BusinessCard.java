package com.example.businesscard.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Blob;

@Entity
@Data
public class BusinessCard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // 명함의 ID
    private String name;  // 이름
    private String position;  // 직책
    private String phoneNumber;  // 핸드폰 번호
    private String officePhone;  // 사무실 전화번호
    private String email;  // 이메일
    private String address;  // 주소
    @Lob
    private String image;
}
