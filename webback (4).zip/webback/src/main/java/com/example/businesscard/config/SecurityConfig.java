//package com.example.businesscard.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders  .HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//import java.util.Arrays;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//    @Bean
//    public CorsConfigurationSource corsConfigurationSource() {
//        CorsConfiguration configuration = new CorsConfiguration();
//        configuration.setAllowedOrigins(Arrays.asList("http://localhost:5173", "http://localhost:5174", "http://localhost:8080")); // 허용할 출처를 명시적으로 지정
////        configuration.setAllowedOriginPatterns(Arrays.asList("*")); // 모든 출처 허용 패턴 지정
//        configuration.setAllowedMethods(Arrays.asList("*")); // 모든 HTTP 메서드 허용
//        configuration.setAllowedHeaders(Arrays.asList("*")); // 모든 헤더 허용
//        configuration.setAllowCredentials(true); // 자격 증명 허용
//        configuration.addExposedHeader("Authorization");    // Expose Authorization header
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", configuration); // 모든 경로에 대해 CORS 설정 적용
//
//        return source;
//    }
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                .authorizeHttpRequests(auth -> auth
//                        .requestMatchers("/api/**", "/scan").permitAll()  // 로그인 및 API 경로 허용
//                        .anyRequest().authenticated()  // 그 외 경로는 인증 필요
//                )
//                .formLogin(form -> form
//                        .loginPage("/loginPage")    // /login 설정시 문제발생, 회피할것
//                        .loginProcessingUrl("/perform_login")   //미설정시 POST /login 요청을 처리해야 하나 문제발생, 다음처럼 설정할것
//                        .defaultSuccessUrl("/", true)   //로그인 성공 시 이동 경로
//                        .permitAll()
//                )
//
//                //로그아웃은 /logout URL 이 기본값이며 동작함
//                .logout(logout -> logout
//                        .permitAll()
//                )
//                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
//                .csrf(csrf -> csrf
//                        .ignoringRequestMatchers("/api/**", "/scan")
//                        .disable()) // CSRF 비활성화
//                .logout(logout -> logout.permitAll());
//
//        return http.build();
//    }
//
//    @Bean
//    public WebSecurityCustomizer webSecurityCustomizer() {
//        return web -> web.ignoring().requestMatchers(
//                "/resources/**",
//                "/static/**",
//                "/css/**",
//                "/js/**",
//                "/assets/**",   /*리액트JS 빌드 기본 리소스*/
//                "/images/**",
//                "/error/**",
//                "/",
//                "/index.html",
//                "/pages/**",    /*프론트엔드의 컴포넌트 라우팅 경로*/
//                "/favicon.*"
//        );
//    }
//}
