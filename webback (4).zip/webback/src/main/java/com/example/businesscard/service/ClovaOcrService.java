package com.example.businesscard.service;

import com.example.businesscard.entity.BusinessCard;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Service
public class ClovaOcrService {

    private final String apiUrl = "https://pi64b4jgl9.apigw.ntruss.com/custom/v1/34164/740eb7c021863a3feb5a3979a5eb134176570673dca638544b4f498e03d6906f/infer"; // OCR API URL (도메인 ID 포함)
    private final String ocrSecret = "ZUVFS0lrQ0F1RmRKUHVPTnRuWnF4b0lEekxZcWxmTXg=";
    private final String apiKey = "ncp_iam_BPAMKR5dt16febDrNCFw"; // 본인의 API Key
    private final String templateId = "32453"; // 사용하려는 템플릿 ID

    public BusinessCard scanBusinessCard(String base64Image) throws IOException {
        long timestamp = Instant.now().toEpochMilli();

        // API 요청 바디 구성
        Map<String, Object> body = new HashMap<>();
        Map<String, String> image = new HashMap<>();
        image.put("format", "png");
        image.put("name", "sample");
        image.put("data", base64Image);

        body.put("images", Arrays.asList(image));  // List로 변경
        body.put("version", "V2");
        body.put("requestId", "unique_request_id");
        body.put("timestamp", timestamp);  // 숫자 값 그대로 사용
        body.put("templateIds", new String[]{templateId}); // 템플릿 ID 추가

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // HTTP POST 요청 생성
            HttpPost request = new HttpPost(apiUrl);
            request.setHeader("X-OCR-SECRET", ocrSecret);
            request.setHeader("X-NCP-APIGW-API-KEY-ID", apiKey);
            request.setHeader("Content-Type", "application/json");

            // JSON 바디 전송
            ObjectMapper objectMapper = new ObjectMapper();
            StringEntity entity = new StringEntity(objectMapper.writeValueAsString(body));
            request.setEntity(entity);

            // API 응답 처리
            HttpResponse response = httpClient.execute(request);
            String jsonResponse = EntityUtils.toString(response.getEntity());
            System.out.println("OCR API Response: " + jsonResponse);

            // 응답에서 명함 정보를 파싱하여 BusinessCard 객체 생성
            return parseBusinessCardFromResponse(jsonResponse);

        } catch (IOException e) {
            System.err.println("OCR API 호출 실패: " + e.getMessage());
            throw e;
        }
    }

    // OCR API 응답을 바탕으로 BusinessCard 객체 생성
    private BusinessCard parseBusinessCardFromResponse(String jsonResponse) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(jsonResponse);

        BusinessCard card = new BusinessCard();
        StringBuilder officePhoneBuilder = new StringBuilder();

        // OCR 응답 구조에 따라 필드 추출
        JsonNode inferTexts = rootNode.path("images").get(0).path("fields");

        for (JsonNode field : inferTexts) {
            String text = field.path("inferText").asText();

            // 이름 필드 추출
            if (fieldMatches("name", text)) {
                card.setName(text);
            }
            // 핸드폰번호 패턴 감지
            else if (fieldMatches("phone", text)) {
                card.setPhoneNumber(text);
            }
            // 직책 추출 (일반적으로 "사장", "대표", "팀장" 등 포함)
            else if (fieldMatches("position", text)) {
                card.setPosition(text);
            }
            // 사무실 전화번호 패턴 감지
            else if (text.startsWith("TEL")) {
                officePhoneBuilder.append(text.replace("TEL", "").trim());
            }
            // 이메일 패턴 감지
            else if (text.contains("@")) {
                card.setEmail(text);
            }
            // 주소 패턴 감지
            else if (fieldMatches("address", text)) {
                card.setAddress(text);
            }
        }

        // 사무실 전화번호 완성
        card.setOfficePhone(officePhoneBuilder.toString());

        return card;
    }

    // 필드 매칭을 위한 헬퍼 메서드
    private boolean fieldMatches(String fieldName, String text) {
        switch (fieldName) {
            case "name":
                return text.matches("^[가-힣]{2,3}$");  // 한글 이름 2~3글자
            case "phone":
                return text.matches("^(010|011|016|017|018|019)-?\\d{3,4}-?\\d{4}$");  // 한국 휴대폰 번호 패턴
            case "position":
                return text.contains("장") || text.contains("사장") || text.contains("대표") || text.contains("팀장") || text.contains("마스터");
            case "address":
                return text.contains("시") || text.contains("구") || text.contains("동") || text.contains("로");  // 한국 주소 패턴
            default:
                return false;
        }
    }
}
