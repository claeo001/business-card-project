package com.example.businesscard.controller;

import com.example.businesscard.entity.BusinessCard;
import com.example.businesscard.service.BusinessCardService;
import com.example.businesscard.service.ClovaOcrService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class BusinessCardController {

    @Autowired
    private ClovaOcrService clovaOcrService;

    @Autowired
    private BusinessCardService businessCardService;

    // 명함 업로드 및 인식 처리 (JSON 응답 반환)
    @PostMapping("/scan")
    public ResponseEntity<Map<String, Object>> scanBusinessCard(@RequestParam("file") MultipartFile file) {
        Map<String, Object> response = new HashMap<>();

        if (file.isEmpty()) {
            response.put("error", "파일을 선택하지 않았습니다.");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            String base64Image = "";

            if (file.getContentType().equals("image/jpeg")) {
                // JPG인 경우 PNG로 변환
                BufferedImage image = ImageIO.read(file.getInputStream());
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(image, "png", baos);
                baos.flush();
                byte[] pngData = baos.toByteArray();
                baos.close();
                base64Image = Base64.getEncoder().encodeToString(pngData);
            } else {
                // PNG인 경우
                base64Image = Base64.getEncoder().encodeToString(file.getBytes());
            }

            // CLOVA OCR 인식 처리
            BusinessCard card = clovaOcrService.scanBusinessCard(base64Image);
            card.setImage(base64Image);

            if (card != null) {
                response.put("name", card.getName());
                response.put("position", card.getPosition());
                response.put("phoneNumber", card.getPhoneNumber());
                response.put("officePhone", card.getOfficePhone());
                response.put("email", card.getEmail());
                response.put("address", card.getAddress());
                response.put("image", base64Image); // base64 인코딩된 이미지도 포함
                return ResponseEntity.ok(response);
            } else {
                response.put("error", "명함 인식에 실패했습니다.");
                return ResponseEntity.badRequest().body(response);
            }
        } catch (IOException e) {
            e.printStackTrace();
            response.put("error", "파일 처리 중 오류가 발생했습니다.");
            return ResponseEntity.status(500).body(response);
        }
    }

    // 명함 저장
    @PostMapping("/save-card")
    public ResponseEntity<Void> saveBusinessCard(@RequestBody BusinessCard card) {
        businessCardService.saveBusinessCard(card);
        return ResponseEntity.ok().build();
    }

    // 명함 편집 처리
    @GetMapping("/edit/{id}")
    public ResponseEntity<BusinessCard> editBusinessCard(@PathVariable Long id) {
        BusinessCard card = businessCardService.getBusinessCardById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 ID의 명함을 찾을 수 없습니다: " + id));
        return ResponseEntity.ok(card);
    }

    // 명함 업데이트
    @PostMapping("/update-card")
    public ResponseEntity<Void> updateBusinessCard(@RequestBody BusinessCard updatedCard) {
        businessCardService.updateBusinessCard(updatedCard);
        return ResponseEntity.ok().build();
    }

    // 명함 삭제
    @DeleteMapping("/delete-card/{id}")
    public ResponseEntity<Void> deleteBusinessCard(@PathVariable Long id) {
        businessCardService.deleteBusinessCard(id);
        return ResponseEntity.ok().build();
    }

    // 저장된 명함 리스트 보여주기
    @GetMapping("/list")
    public ResponseEntity<List<BusinessCard>> listBusinessCards() {
        List<BusinessCard> cards = businessCardService.getAllBusinessCards();
        return ResponseEntity.ok(cards);
    }
}
