package com.example.businesscard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinesscardApplicationTests {

	@Test
	void contextLoads() {
	}

}
