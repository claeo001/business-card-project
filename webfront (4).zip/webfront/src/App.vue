<template>
  <div class="background-image">
    <header>
      <img src="./assets/logo.png" alt="GotBusinesscard Logo" class="logo" />
      <div class="menu">
        <router-link
          v-for="menuItem in menuItems"
          :key="menuItem"
          :to="getMenuPath(menuItem)"
        >
          {{ menuItem }}
        </router-link>
      </div>
      <div class="auth-links">
        <a href="#">로그인</a> | <a href="#">회원가입</a> | <a href="#">장바구니</a>
      </div>
    </header>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      menuItems: ['Home', '도입 문의', '개인용 서비스', 'NFC 스토어', '기업소개'],
    };
  },
  methods: {
    getMenuPath(menuItem) {
      if (menuItem === '개인용 서비스') {
        return '/personal-service';
      }
      return '/';
    },
  },
};
</script>

<style scoped>
/* 스타일은 그대로 유지합니다 */
.background-image {
  background-image: url('./assets/background-image.png');
  background-size: cover;
  background-position: center;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2%;
}
.logo {
  width: 200px; /* 로고 크기 조정 */
  margin-left: 20px; /* 로고 위치 오른쪽 이동 */
}
.menu {
  display: flex;
  gap: 20px;
}
.menu a {
  color: black;
  text-decoration: none;
  font-weight: bold;
  font-size: 18px;
  padding: 10px;
  cursor: pointer;
}
.auth-links {
  display: flex;
  gap: 10px;
}
</style>
