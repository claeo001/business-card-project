import { createRouter, createWebHistory } from 'vue-router';
import Home from '../components/HomePage.vue';
import PersonalService from '../components/PersonalService.vue';
import BusinessCardResult from '../components/BusinessCardResult.vue'; // 명함 인식 결과 페이지
import BusinessCardList from '../components/BusinessCardList.vue'; // 나의 명함집

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    path: '/personal-service',
    name: 'PersonalService',
    component: PersonalService,
  },
  {
    path: '/business-card-result/:id',
    name: 'BusinessCardResult',
    component: BusinessCardResult,
    props: route => {
      let recognizedData;
      try {
        recognizedData = JSON.parse(route.query.recognizedData || '{}');
      } catch (error) {
        console.error('JSON 파싱 오류:', error);
        recognizedData = {};
      }
      return {
        recognizedData,
        imageUrl: route.query.imageUrl || ''
      };
    },
  },
  {
    path: '/business-card-list',
    name: 'BusinessCardList',
    component: BusinessCardList,
  },
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});

export default router;
