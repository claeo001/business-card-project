<template>
  <div class="business-card-result">
    <h1>명함 인식 결과</h1>
    <div class="card-preview">
      <!-- 업로드된 이미지 표시 -->
      <img :src="imageUrl" alt="Uploaded Business Card" v-if="imageUrl" />
      <p v-else>이미지가 없습니다. 이전 페이지로 돌아가 이미지를 업로드하세요.</p>

      <!-- 명함 인식 결과 입력 -->
      <table>
        <thead>
          <tr>
            <th>필드</th>
            <th>내용</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>이름</td>
            <td><input type="text" v-model="recognizedData.name"/></td>
          </tr>
          <tr>
            <td>직책</td>
            <td><input type="text" v-model="recognizedData.position" /></td>
          </tr>
          <tr>
            <td>핸드폰번호</td>
            <td><input type="text" v-model="recognizedData.mobileNumber" /></td>
          </tr>
          <tr>
            <td>사무실 전화번호</td>
            <td><input type="text" v-model="recognizedData.officePhone" /></td>
          </tr>
          <tr>
            <td>이메일</td>
            <td><input type="text" v-model="recognizedData.email" /></td>
          </tr>
          <tr>
            <td>주소</td>
            <td><input type="text" v-model="recognizedData.address" /></td>
          </tr>
        </tbody>
      </table>
      <div class="actions">
        <button @click="saveRecognition">저장</button>
        <button @click="cancelRecognition">취소</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BusinessCardResult',
  props: {
    recognizedData: {
      type: Object,
      default: () => ({})
    },
    imageUrl: {
      type: String,
      default: ''
    }
  },
  data() {
  },
  created() {
    // 라우터로부터 데이터를 받아서 recognizedData에 저장
    console.log('Received recognizedData:', this.recognizedData);
    console.log('Received imageUrl:', this.imageUrl);
  },
  methods: {
    // 명함 정보를 저장하고 나의 명함집 페이지로 이동
    saveRecognition() {
      // 명함 데이터를 localStorage에 저장 (임시로 사용 가능)
      const cards = JSON.parse(localStorage.getItem('businessCards')) || [];
      cards.push({
        ...this.recognizedData,
        imageUrl: this.imageUrl, // 업로드된 이미지 포함
      });
      localStorage.setItem('businessCards', JSON.stringify(cards));

      // 명함 리스트 페이지로 이동
      this.$router.push('/business-card-list');
    },
    cancelRecognition() {
      this.$router.push('/personal-service'); // 취소 시 PersonalService로 돌아감
    },
  },
};
</script>

<style scoped>
.business-card-result {
  max-width: 900px;
  margin: 0 auto;
  text-align: center;
  position: absolute;
  top: 150px;
  left: 50%;
  transform: translateX(-50%);
}

.card-preview {
  margin-top: 10px;
}

table {
  width: 100%;
  margin: 20px 0;
  border-collapse: collapse;
}

table th, table td {
  border: 1px solid #ddd;
  padding: 15px;
  text-align: left;
  font-size: 17px;
}

.actions {
  display: flex;
  justify-content: center;
  gap: 40px;
  margin-top: 20px;
}

button {
  padding: 10px 30px;
  background-color: #007bff;
  color: white;
  border: none;
  cursor: pointer;
  font-size: 18px;
}

button:hover {
  background-color: #0056b3;
}
</style>
