<template>
  <div class="personal-service-page">
    <!-- 제목과 나만의 명함집 버튼 -->
    <div class="header-section">
      <h1>재생산이 필요 없는 디지털 명함집을 만들어 보세요!</h1>
      <button @click="goToBusinessCardList" class="card-list-button">나만의 명함집</button>
    </div>

    <div class="content">
      <img src="@/assets/personal-service-image.png" alt="Personal Service" />
      <div class="description">
        <h2>개인/조직 브랜딩</h2>
        <p>디지털 명함을 통해 차별화된 개인과 기업의 비즈니스를 전달해요.</p>
        <h2>재생산없는 커스텀</h2>
        <p>직책 정보, 사무실 정보가 변경되면 편리하게 상시 수정하고 사용해요.</p>
        <h2>온, 오프라인 무제한 공유</h2>
        <p>하나의 디지털 명함을 제작하면 소진 걱정 없이 공유할 수 있어요.</p>
      </div>
    </div>

    <div class="business-card-registration">
      <h2>나만의 명함집을 만들어 보세요</h2>
      <div class="card-upload-section">
        <!-- 이미지 업로드 버튼 -->
        <input type="file" @change="handleFileUpload" style="display: none;" ref="fileInput" />
        <button @click="triggerFileUpload">이미지 업로드</button>
        <!-- 선택된 파일명 표시 -->
        <p v-if="uploadedFileName">선택된 파일: {{ uploadedFileName }}</p>
        <p v-else>선택된 파일 없음</p>
        <button @click="goToBusinessCardResult">명함 인식하기</button>
        <p>명함 이미지를 업로드하여 명함집에 넣어주세요!</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'PersonalService',
  data() {
    return {
      uploadedFileName: '', // 업로드된 파일명을 저장
      uploadedFileUrl: '', // 업로드된 파일 URL을 저장
    };
  },
  methods: {
    // 파일 업로드 창 열기
    triggerFileUpload() {
      this.$refs.fileInput.click();
    },
    // 파일 선택 시 호출되는 메소드
    handleFileUpload(event) {
      const file = event.target.files[0]; // 업로드된 첫 번째 파일
      if (file) {
        this.uploadedFileName = file.name; // 파일명을 저장
        this.uploadedFileUrl = URL.createObjectURL(file); // 파일 URL 생성
      } else {
        this.uploadedFileName = '';
        this.uploadedFileUrl = '';
      }
    },
    // 명함 인식 결과 페이지로 이동
    async goToBusinessCardResult() {
      if (this.uploadedFileUrl) {
        const fileInput = this.$refs.fileInput.files[0];
        const formData = new FormData();
        formData.append('file', fileInput);

        try {
          const response = await axios.post('http://localhost:8080/scan', formData, {
            headers: {
              'Content-Type': 'multipart/form-data',
            }
          });

          const recognizedData = {
            name: response.data.name || '이름 없음',
            position: response.data.position || '직책 없음',
            mobileNumber: response.data.mobileNumber || '번호 없음',
            officePhone: response.data.officePhone || '사무실 번호 없음',
            email: response.data.email || '이메일 없음',
            address: response.data.address || '주소 없음',
          };
          
          const imageUrl = 'data:image/png;base64,' + (response.data.image || '');
          
          // 라우터 네비게이션 수정
          this.$router.push({
            name: 'BusinessCardResult',
            params: { id: Date.now().toString() },
            query: {
              recognizedData: JSON.stringify(recognizedData),
              imageUrl: imageUrl
            }
          });
        } catch (error) {
          console.error('명함 인식 오류:', error);
          alert('명함 인식에 실패했습니다.');
        }
      } else {
        alert('이미지를 먼저 업로드하세요.');
      }
    },
    // 나만의 명함집 페이지로 이동
    goToBusinessCardList() {
      this.$router.push('/business-card-list');
    },
  },
};
</script>

<style scoped>
.personal-service-page {
  text-align: center;
  padding: 50px;
  background-color: white;
}

/* 제목과 버튼을 포함하는 섹션 스타일 */
.header-section {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 80px; /* 제목과 버튼 사이의 간격을 넓힘 */
  margin-bottom: 40px; /* 제목과 밑의 내용 간격 */
}

.card-list-button {
  background-color: #007bff;
  color: white;
  padding: 12px 25px;
  border: none;
  cursor: pointer;
  font-size: 18px; /* 버튼 글자 크기 확대 */
}

.card-list-button:hover {
  background-color: #0056b3;
}

.content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 50px;
  flex-wrap: wrap;
  margin: 20px auto;
  max-width: 1200px;
  line-height: 1.8; /* 줄 간격 추가 */
}

img {
  max-width: 500px;
  height: auto;
  margin: 0 auto;
}

.description {
  text-align: left;
  max-width: 500px;
  margin: 0 auto;
}

.business-card-registration {
  text-align: center;
  padding: 30px;
  border: 1px solid #ddd;
  margin-top: 50px; /* 상단과의 간격을 넓힘 */
}

.business-card-registration h2 {
  font-size: 28px; /* 타이틀 글자 크기 키움 */
}

.card-upload-section button {
  background-color: #007bff;
  color: white;
  padding: 15px 30px;
  border: none;
  cursor: pointer;
  margin: 15px;
  font-size: 18px; /* 버튼 글자 크기 확대 */
}

.card-upload-section button:hover {
  background-color: #0056b3;
}

.card-upload-section p {
  font-size: 20px; /* 파일명 및 설명 글자 크기 확대 */
  margin: 10px 0;
}
</style>
