<template>
    <div class="business-card-list">
      <h1>나만의 명함집</h1>
      <!-- 검색 기능 -->
      <input
        type="text"
        placeholder="검색어를 입력하세요"
        v-model="searchQuery"
      />
      <table>
        <thead>
          <tr>
            <th>이름</th>
            <th>직책</th>
            <th>이메일</th>
            <th>핸드폰번호</th>
            <th>사무실 전화번호</th>
            <th>주소</th>
            <th>이미지</th>
            <th>작업</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(card, index) in filteredCards" :key="index">
            <td>{{ card.name }}</td>
            <td>{{ card.position }}</td>
            <td>{{ card.email }}</td>
            <td>{{ card.mobileNumber }}</td>
            <td>{{ card.officePhone }}</td>
            <td>{{ card.address }}</td>
            <td><img :src="card.imageUrl" alt="Business Card" width="100" /></td>
            <td>
              <!-- 편집 버튼 -->
              <button @click="editCard(index)">편집</button>
              <!-- 삭제 버튼 -->
              <button @click="deleteCard(index)">삭제</button>
            </td>
          </tr>
        </tbody>
      </table>
      <button @click="goHome">홈으로 돌아가기</button>
    </div>
  </template>
  
  <script>
  export default {
    name: 'BusinessCardList',
    data() {
      return {
        searchQuery: '',
        businessCards: [],
      };
    },
    computed: {
      filteredCards() {
        if (!this.searchQuery) return this.businessCards;
        return this.businessCards.filter((card) =>
          Object.values(card).some((value) =>
            value.toString().toLowerCase().includes(this.searchQuery.toLowerCase())
          )
        );
      },
    },
    methods: {
      deleteCard(index) {
        this.businessCards.splice(index, 1);
        localStorage.setItem('businessCards', JSON.stringify(this.businessCards));
      },
      editCard(index) {
        const cardToEdit = this.businessCards[index];
        this.$router.push({
          name: 'BusinessCardResult',
          params: { card: cardToEdit, isEditing: true },
        });
      },
      goHome() {
        this.$router.push('/');
      },
    },
    mounted() {
      const storedCards = JSON.parse(localStorage.getItem('businessCards')) || [];
      this.businessCards = storedCards;
    },
  };
  </script>
  
  <style scoped>
  .business-card-list {
    max-width: 1200px;
    margin: 0 auto;
    text-align: center;
    position: absolute; /* 화면 상단으로 고정 */
    top: 200px; /* 화면 상단에서 100px 내려오도록 설정 */
    left: 50%; /* 가운데 정렬 */
    transform: translateX(-50%); /* 가운데 정렬을 위한 transform */
  }
  
  table {
    width: 100%;
    margin: 20px 0;
    border-collapse: collapse;
  }
  
  table th,
  table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
  }
  
  input[type="text"] {
    margin-bottom: 20px;
    padding: 10px;
    width: 300px;
  }
  
  button {
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    cursor: pointer;
    margin: 5px;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  </style>
  