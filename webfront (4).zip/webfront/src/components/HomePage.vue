<template>
  <main>
    <div class="text-overlay">
      <h2 class="branding-text">명함은 관계의 첫인상을 만드는 가장 효과적인 브랜딩 툴입니다.</h2>
      <h1 class="headline">GotBusinessCard는, 명함이 자신의 본질을 다하도록 정리해 드립니다.</h1>
    </div>
  </main>
</template>

<script>
export default {
  name: 'HomePage',
};
</script>

<style scoped>
.text-overlay {
  text-align: center;
  margin-top: -600px; /* 위치 조정 */
}

.branding-text {
  font-size: 25px;
  color: rgb(37, 31, 207);
  margin: 10px 0;
  line-height: 1.8; /* 줄 간격 추가 */
}

.headline {
  font-size: 30px;
  font-weight: bold;
  margin: 10px 0;
  line-height: 1.8; /* 줄 간격 추가 */
}
</style>
